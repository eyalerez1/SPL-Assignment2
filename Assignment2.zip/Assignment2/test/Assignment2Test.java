package bgu.spl;
import bgu.spl.mics.impl.*;
import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import bgu.spl.mics.MessageBus;
import bgu.spl.mics.impl.MessageBusImpl;

import bgu.spl.mics.*;
import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import bgu.spl.mics.MessageBus;
import bgu.spl.mics.impl.MessageBusImpl;

public class Assignment2Test {
	
	MessageBusImpl m;
	Request[] r;
	Broadcast[] b;
	MicroService[] ms;
	
	
	@Before
	public void setUp() throws Exception {
		m=MessageBusImpl.getInstance();
		r=new Request[3];
		r[0]=new Request1();
		r[1]=new Request2();
		r[2]=new Request3();
		b=new Broadcast[3];
		b[0]=new Broadcast1();
		b[1]=new Broadcast2();
		b[2]=new Broadcast3();

		ms= new MicroService[3];
		ms[0]=new MicroService1("ms1");
		
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testGetInstance() {
		assertEquals(true,MessageBusImpl.getInstance()==m);
	}

	@Test
	public void testSubscribeRequest() {
		Thread t1=new Thread(ms[0]);
		t1.start();
		
	}

	@Test
	public void testSubscribeBroadcast() {
		fail("Not yet implemented");
	}

	@Test
	public void testComplete() {
		fail("Not yet implemented");
	}

	@Test
	public void testSendBroadcast() {
		fail("Not yet implemented");
	}

	@Test
	public void testSendRequest() {
		fail("Not yet implemented");
	}

	@Test
	public void testRegister() {
		fail("Not yet implemented");
	}

	@Test
	public void testUnregister() {
		fail("Not yet implemented");
	}

	@Test
	public void testAwaitMessage() {
		fail("Not yet implemented");
	}

}

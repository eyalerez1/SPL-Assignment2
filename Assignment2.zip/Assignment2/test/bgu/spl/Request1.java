package bgu.spl;

import bgu.spl.mics.Request;

public class Request1 implements Request<Boolean> {
	public Request1() {
		
	}
}

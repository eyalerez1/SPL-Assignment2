package bgu.spl;

import bgu.spl.mics.Broadcast;

public class Broadcast2 implements Broadcast {
	public Broadcast2() {
		
	}

}

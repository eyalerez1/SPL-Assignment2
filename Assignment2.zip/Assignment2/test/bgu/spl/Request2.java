package bgu.spl;

import bgu.spl.mics.Request;

public class Request2 implements Request<Boolean> {
	public Request2() {
		
	}
}

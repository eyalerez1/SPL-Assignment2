package bgu.spl;

import bgu.spl.mics.Request;

public class Request3 implements Request<Boolean> {
	public Request3() {
		
	}
}

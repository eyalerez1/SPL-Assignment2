package bgu.spl;

import bgu.spl.mics.Broadcast;

public class Broadcast1 implements Broadcast {
	public Broadcast1() {
		
	}

}

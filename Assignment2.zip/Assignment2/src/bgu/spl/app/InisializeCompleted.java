package bgu.spl.app;

import bgu.spl.mics.Broadcast;

/**
 * A broadcast message which indicates that the initialization of a {@link MicroService} was completed successfully
 * @author USER
 *
 */
public class InisializeCompleted implements Broadcast {
	
}

package bgu.spl.app;

import java.util.concurrent.atomic.*;

// TODO: Auto-generated Javadoc
/**
 * The Class Pair holds a ManufacturingOrderRequest and an AtomicInteger with the remaining amount of shoes.
 */
public class Pair {
	
	private ManufacturingOrderRequest requests;
	private AtomicInteger remainingAmountOfShoes;
	
	/**
	 * Instantiates a new pair.
	 *
	 * @param requests the requests
	 */
	public Pair(ManufacturingOrderRequest requests) {
		this.requests = requests;
		this.remainingAmountOfShoes = new AtomicInteger(requests.getAmount());
	}
	
	/**
	 * Gets the remaining amount of shoes.
	 *
	 * @return the remaining amount of shoes
	 */
	public AtomicInteger getRemainingAmountOfShoes() {
		return remainingAmountOfShoes;
	}

	/**
	 * Sets the remaining amount of shoes.
	 */
	public void setRemainingAmountOfShoes() {
		remainingAmountOfShoes.decrementAndGet();
	}

	/**
	 * Gets the requests.
	 *
	 * @return the requests
	 */
	public ManufacturingOrderRequest getRequests() {
		return requests;
	}

	
	
	


}

package bgu.spl.app;

import java.util.Comparator;

// TODO: Auto-generated Javadoc
/**
 * The Class Schedule.
 */
public abstract class Schedule {
	
	/**
	 * The Class ScheduleComparator.
	 */
	private static class ScheduleComparator implements Comparator<Schedule> {
		
		/* (non-Javadoc)
		 * @see java.util.Comparator#compare(java.lang.Object, java.lang.Object)
		 */
		public int compare(Schedule p1, Schedule p2) {
			return p1.getTick()-p2.getTick();
		}
	}
	
	/**
	 * Gets the comparator.
	 *
	 * @return the comparator
	 */
	public static Comparator<Schedule> getComparator() {
		return new ScheduleComparator();
	}
	
	/**
	 * Gets the tick.
	 *
	 * @return the tick
	 */
	public abstract int getTick();

}

package bgu.spl.app;

import java.util.*;
import java.util.concurrent.atomic.*;;

// TODO: Auto-generated Javadoc
/**
 * The Class RestockRequestManager.
 */
public class RestockRequestManager {
	

		/** The num. */
		private AtomicInteger num;
		
		/** The bool. */
		private boolean bool;
		
		/** The requests. */
		private LinkedList<RestockRequest> requests; 
		
		/**
		 * Instantiates a new restock request manager.
		 *
		 * @param num the num
		 * @param bool the bool
		 */
		public RestockRequestManager(AtomicInteger num, boolean bool) {
			this.num = num;
			this.bool = bool;
			requests=new LinkedList<RestockRequest>();
		}
		
		/**
		 * Gets the num.
		 *
		 * @return the num
		 */
		public AtomicInteger getNum() {
			return num;
		}
		
		/**
		 * Checks if is completed.
		 *
		 * @return true, if is completed
		 */
		public boolean isCompleted() {
			return bool;
		}
		
		/**
		 * Sets the completed.
		 *
		 * @param bool the new completed
		 */
		public void setCompleted(boolean bool) {
			this.bool = bool;
		}
		
		/**
		 * Adds the request.
		 *
		 * @param request the request
		 */
		public void addRequest(RestockRequest request) {
			requests.add(request);
			num.decrementAndGet();
		}
		
		/**
		 * Gets the requests.
		 *
		 * @return the requests
		 */
		public LinkedList<RestockRequest> getRequests() {
			return requests;
		}

}

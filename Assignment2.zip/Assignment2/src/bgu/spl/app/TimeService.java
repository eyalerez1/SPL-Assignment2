package bgu.spl.app;

import java.util.logging.Logger;

import bgu.spl.mics.MicroService;
import bgu.spl.mics.impl.MessageBusImpl;

// TODO: Auto-generated Javadoc
/**
 * This MicroService is the global system timer.
 */
public class TimeService extends MicroService {
	
	private int speed;
	private int duration;
	private int currentTick;
	private Logger logger=Logger.getLogger("ShoeStoreLogger");

	
	/**
	 * Instantiates a new time service.
	 *
	 * @param speed the number of milliseconds between each tick
	 * @param duration the duration of the program
	 */
	public TimeService(int speed, int duration) {
		super("timer");
		this.speed = speed;
		this.duration = duration;
		this.currentTick=1;
	}
	 /**
		 * subscribes to relevant Requests and Broadcasts
		 * this method is called once when the event loop starts. 
		 */
	@Override
	protected void myFunc(){
		sendBroadcast(new InisializeCompleted());
		logger.info("The Timer initialized successfully");

		try {
			MessageBusImpl.getInstance().wait();
		}catch(InterruptedException e) {}
		
		
		while(currentTick<duration) {
			sendBroadcast(new TickBroadcast(currentTick));
			logger.info("The Timer sent TickBroadcast: "+currentTick);

			try {
				this.wait(speed);;
			} catch(InterruptedException e) {}
			
		}
		
		sendBroadcast(new TerminationBroadcast());
		logger.info("The timer is about to terminate");
		terminate();
	}
}

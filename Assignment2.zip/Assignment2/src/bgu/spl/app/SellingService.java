package bgu.spl.app;

import java.util.logging.Logger;

import bgu.spl.mics.MicroService;
import bgu.spl.mics.impl.MessageBusImpl;

/**
 * This MicrService handles PurchaseOrderRequest.
 */
public class SellingService extends MicroService {
	
	private int currentTick;
	private Store myStore;
	private Logger logger=Logger.getLogger("ShoeStoreLogger");
	 
	/**
	 * Instantiates a new selling service.
	 */
	public SellingService() {
		 super("Seller");
		 myStore=Store.getInstance();
	 }
	 /**
	 * subscribes to relevant Requests and Broadcasts
	 * this method is called once when the event loop starts. 
	 */
	@Override
	protected void myFunc() {
		subscribeBroadcast(TickBroadcast.class, (TickBroadcast tick)->{
			currentTick=tick.getCurrentTick();
			logger.info("The Seller updated his tick to "+currentTick);
		});
		logger.info("The seller subscribed to TickBroadcast");
		
		subscribeBroadcast(TerminationBroadcast.class, (TerminationBroadcast t)->{
			logger.info("The seller is about to terminate");
			terminate();
		} );
		logger.info("The seller subscribed to TickBroadcast");
		
		subscribeRequest(PurchaseOrderRequest.class, (PurchaseOrderRequest request)-> {
			//callback of PurchaseOrderRequest
			logger.info("The seller received a PurchaseOrderRequest by "+request.getRequester());
			BuyResult buyResult=myStore.take(request.getShoeType(), request.isOnlyDiscount());
			
			switch (buyResult){
			case NOT_IN_STOCK: 
				sendRequest(new RestockRequest(request.getShoeType()),(result)->{
					//callback of RestockRequest completed
					if(!result) {
						complete(request,null);
					} else {
						complete(request,new Receipt(super.getName(), request.getRequester(), request.getShoeType(), false, currentTick, request.getIssuedTick(), 1));
					}
					//end of callback of RestockRequest completed
				});
				logger.info("The seller sent a RestockRequest of "+request.getShoeType());
				break;
				
			case NOT_ON_DISCOUNT:
				complete(request,null);
				break;
				
			case REGULAR_PRICE:
				Receipt receipt= new Receipt(super.getName(), request.getRequester(), request.getShoeType(), false, currentTick, request.getIssuedTick(), 1);
				myStore.file(receipt);
				complete(request, receipt);
				break;
				
			case DISCOUNTED_PRICE:
				Receipt discountReceipt= new Receipt(super.getName(), request.getRequester(), request.getShoeType(), true, currentTick, request.getIssuedTick(), 1);
				myStore.file(discountReceipt);
				complete(request, discountReceipt);
				break;
			}//end of callback of PurchaseOrderRequest				
		});
		logger.info("The seller subscribed to PurchaseOrderRequest");
		subscribeBroadcast(NewDiscountBroadcast.class, (NewDiscountBroadcast broadcast)->{
															myStore.addDiscount(broadcast.getShoeType(), broadcast.getAmount());});
		logger.info("The seller subscribed to NewDiscountBroadcast");
	
		sendBroadcast(new InisializeCompleted());
		logger.info("The seller initialized successfully");
		try {
			MessageBusImpl.getInstance().wait();
		}catch(InterruptedException e) {}
	
	}
}

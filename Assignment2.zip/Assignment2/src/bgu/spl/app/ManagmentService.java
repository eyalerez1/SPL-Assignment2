package bgu.spl.app;

import bgu.spl.mics.MicroService;

import bgu.spl.mics.impl.MessageBusImpl;

import java.util.*;
import java.util.concurrent.atomic.*;
import java.util.logging.Logger;

/**
 * The ManagementService is a {@link MicroService} that uses the {@link MessageBus} in
 * order to communicate with other services.
 * @author USER
 *
 */

public class ManagmentService extends MicroService {
	
	private int currentTick;
	private Store myStore;
	private PriorityQueue<DiscountSchedule> discountSchedule;
	private HashMap<String,RestockRequestManager> expectedShoesNumber;
	private Logger logger=Logger.getLogger("ShoeStoreLogger");
	
	public ManagmentService(List<DiscountSchedule> discountSchedule) {
		super("manager");
		myStore=Store.getInstance();
		this.currentTick = 1;
		this.discountSchedule = new PriorityQueue<DiscountSchedule>(1, DiscountSchedule.getComparator()); 
		this.discountSchedule.addAll(discountSchedule);
		expectedShoesNumber= new HashMap<String,RestockRequestManager>();
		
	}
	
    /**
	 * subscribes to relevant Requests and Broadcasts
	 * this method is called once when the event loop starts. 
	 */
	protected void myFunc() {
		subscribeBroadcast(TickBroadcast.class, (TickBroadcast tick)->{
			currentTick=tick.getCurrentTick();
			logger.info("The manager updated his tick to "+currentTick);
			if(discountSchedule.peek().getTick()==currentTick) {
				DiscountSchedule d=discountSchedule.poll();
				sendBroadcast(new NewDiscountBroadcast(d.getShoeType(),d.getAmount()));
				logger.info("The manager sent a new discount broadcast");
			}	
		});
		logger.info("The manager subscribed to TickBroadcast");

		subscribeBroadcast(TerminationBroadcast.class, (TerminationBroadcast t)->{
			logger.info("The manager is about to terminate");
			terminate();
		});
		logger.info("The manager subscribed to TerminationBroadcast");
		
		subscribeRequest(RestockRequest.class, (RestockRequest request)->{ //callback of RestockRequest
			RestockRequestManager p=expectedShoesNumber.get(request.getShoeType());
			if(p==null || p.getNum().get()==0) {
				AtomicInteger numberOfOrders=new AtomicInteger((currentTick%5)+1);
				logger.info("Manager sent a RestockRequest of "+numberOfOrders+" of "+request.getShoeType());
				sendRequest(new ManufacturingOrderRequest(request.getShoeType(),numberOfOrders.get(),currentTick), (result)->{
					//callback of ManufacturingOrderRequest Completed
					if(result!=null){
						logger.info("Manager received a ManufacturingOrderRequest completed of "+numberOfOrders+" of "+request.getShoeType());
						myStore.add(request.getShoeType(), expectedShoesNumber.get(request.getShoeType()).getNum().get());
						myStore.file(result);
						expectedShoesNumber.get(request.getShoeType()).setCompleted(true);
						for(int i=0; i<numberOfOrders.get() && !expectedShoesNumber.get(request.getShoeType()).getRequests().isEmpty(); i++) {
							complete(expectedShoesNumber.get(request.getShoeType()).getRequests().remove(),true);
						}
					} else{
						logger.info("The ManufacturingOrderRequest of "+numberOfOrders+" of "+request.getShoeType()+" was unsuccessfull");
						for(int i=0; i<numberOfOrders.get() && !expectedShoesNumber.get(request.getShoeType()).getRequests().isEmpty(); i++) {
							complete(expectedShoesNumber.get(request.getShoeType()).getRequests().remove(),false);
						}
					}//end of callback of ManufacturingOrderRequest Completed
				});
				expectedShoesNumber.put(request.getShoeType(), new RestockRequestManager(numberOfOrders,false));
			}
			expectedShoesNumber.get(request.getShoeType()).addRequest(request);
			//end of callback of RestockRequest
		});
		logger.info("The manager subscribed to RestockRequest");
		
		sendBroadcast(new InisializeCompleted());
		logger.info("The manager initialized successfully");
		try {
			MessageBusImpl.getInstance().wait();
		}catch(InterruptedException e) {}
	}

}

package bgu.spl.app;

import bgu.spl.mics.MicroService;
import bgu.spl.mics.impl.MessageBusImpl;

import java.util.*;
import java.util.logging.Logger;

/**
 * This MicroService describes a shoe factory that manufacture shoes for the store.
 */
public class ShoeFactoryService extends MicroService {

	private int currentTick;
	private LinkedList<Pair> orders;
	private Logger logger=Logger.getLogger("ShoeStoreLogger");

	/**
	 * Instantiates a new shoe factory service.
	 */
	public ShoeFactoryService() {
		super("factory");
		currentTick=1;
		orders=new LinkedList<Pair>();
	}
	 /**
	 * subscribes to relevant Requests and Broadcasts
	 * this method is called once when the event loop starts. 
	 */
	@Override
	protected void myFunc() {

		subscribeBroadcast(TickBroadcast.class, (TickBroadcast tick)->{
			currentTick=tick.getCurrentTick();
			logger.info("The factory updated his tick to "+currentTick);
			Pair p=orders.peekFirst();
			if(p!=null) {
				if(p.getRemainingAmountOfShoes().get()==0) {
					logger.info("The factory finished manufactoring the "+p.getRequests().getShoeType()+" order and sent a receipt");
					complete(orders.pollFirst().getRequests(),new Receipt(super.getName(), "store", p.getRequests().getShoeType(), false, currentTick, p.getRequests().getIssuedTick(), p.getRequests().getAmount()));
				}
				p=orders.peekFirst();
				if(p!=null) {
					p.setRemainingAmoutOfShoes();
					logger.info("The factory manufactored a "+p.getRequests().getShoeType());
				}
			}
		});
		logger.info("The factory subscribed to TickBroadcast");
		
		subscribeBroadcast(TerminationBroadcast.class, (TerminationBroadcast t)->{
			logger.info("The factory is about to terminate");
			terminate();
		} );
		logger.info("The factory subscribed to TerminationBroadcast");
		
		sendBroadcast(new InisializeCompleted());
		logger.info("The factory initialized successfully");
		try {
			MessageBusImpl.getInstance().wait();
		}catch(InterruptedException e) {}
	}
}

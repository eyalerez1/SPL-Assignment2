package bgu.spl.app;

import java.util.*;

/**
 * The class contains purchase that the client needs to make.
 */
public class PurchaseSchedule extends Schedule {

	private String shoeType;
	private int tick;
	
	/**
	 * Instantiates a new purchase schedule.
	 *
	 * @param shoeType the shoe type
	 * @param tick the tick
	 */
	public PurchaseSchedule(String shoeType, int tick) {
		this.shoeType = shoeType;
		this.tick = tick;
	}

	/**
	 * Gets the shoe type.
	 *
	 * @return the shoe type
	 */
	public String getShoeType() {
		return shoeType;
	}

	/**
	 * Gets the tick.
	 *
	 * @return the tick
	 */
	public int getTick() {
		return tick;
	}
	

	

	


}

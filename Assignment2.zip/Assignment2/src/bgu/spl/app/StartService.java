package bgu.spl.app;

import bgu.spl.mics.MicroService;
import bgu.spl.mics.impl.MessageBusImpl;

import java.util.concurrent.atomic.*;
import java.util.logging.Logger;

/**
 * The Class StartService is making sure all the MicroServices will start to run on the same tick, after they are all initialized.
 */
public class StartService extends MicroService {
	
	private AtomicInteger countDown;
	private Logger logger=Logger.getLogger("ShoeStoreLogger");

	
	/**
	 * Instantiates a new start service.
	 *
	 * @param countDown the number of MicroServices
	 */
	public StartService(int countDown) {
		super("startService");
		this.countDown=new AtomicInteger(countDown);
	}
	 /**
	 * subscribes to relevant Requests and Broadcasts
	 * this method is called once when the event loop starts. 
	 */
	@Override
	protected void myFunc() {
		subscribeBroadcast(InisializeCompleted.class, (InisializeCompleted i)->{
			if(countDown.decrementAndGet()==0) {
				logger.info("StratService sent notifyAll");
				MessageBusImpl.getInstance().notifyAll();
				terminate();
			}
		});
	}

}

package bgu.spl.mics.impl;

import bgu.spl.mics.Request;

public class Request1 implements Request<Boolean> {
	public Request1() {
		
	}
	public Object getResultType() {
		return Boolean.class;
	}
}

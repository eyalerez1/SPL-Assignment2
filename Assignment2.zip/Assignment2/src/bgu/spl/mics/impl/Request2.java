package bgu.spl.mics.impl;

import bgu.spl.mics.Request;

public class Request2 implements Request<Boolean> {
	public Request2() {
		
	}
}

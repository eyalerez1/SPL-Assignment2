package bgu.spl.mics.impl;


import bgu.spl.MicroService1;
import bgu.spl.mics.Message;

public class Main {

	/*public static void main(String[] args) {
		/*WebSiteClientService w1=new WebSiteClientService("shimi");
		WebSiteClientService w2=new WebSiteClientService("filus");

		MessageBusImpl bus=MessageBusImpl.getInstance();

		bus.register(w2);
		Mock_request m1=new Mock_request();
		bus.sendRequest(m1,w2);
		bus.register(w1);
		bus.subscribeRequest(Mock_request.class,w1);
		bus.sendRequest(m1,w2);
		try {
			Message r1= bus.awaitMessage(w1);
			if (r1==m1)
				System.out.println("dis is good");
		} catch (InterruptedException e) {
			e.printStackTrace();
			System.out.println("were fucked");
		}
		bus.unregister(w2);
		bus.unregister(w1);
		WebSiteClientService w3=new WebSiteClientService("Thread requester");
		WebSiteClientService w4 =new WebSiteClientService("Thread Helper");
		bus.register(w3);
		Thread t1= new Thread() {

			@Override
			public void run() {
				Mock_request r1=new Mock_request();

				try {
					Thread.sleep(4000);
					System.out.println("i will wait for the next guy to wake up");
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				System.out.println("good morning my man");
				bus.sendRequest(r1, w3);
			}
		};
		Thread t2= new Thread() {


			@Override
			public void run() {
				bus.subscribeRequest(Mock_request.class, w3);
				try {
					Message m=bus.awaitMessage(w3);
					System.out.println(m+" i work");
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		};

		System.out.println("------------------------------Thread Check----------------------------------------");

		//t2.start();
	//	t1.start();

		
		MicroService1 ms=new MicroService1("ms1");
		ms.run();
		//Thread t3= new Thread(ms);
		//t3.start();
		


	}

*/
}
